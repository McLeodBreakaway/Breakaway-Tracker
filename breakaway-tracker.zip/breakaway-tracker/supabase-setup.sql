-- ============================================
-- BREAKAWAY TRACKER - Supabase Setup SQL
-- Run this entire file in your Supabase SQL Editor
-- ============================================

-- AGENTS TABLE
create table if not exists agents (
  id uuid default gen_random_uuid() primary key,
  name text not null unique,
  created_at timestamp with time zone default now()
);

-- ENTRIES TABLE (daily stat logs)
create table if not exists entries (
  id uuid default gen_random_uuid() primary key,
  agent_id uuid references agents(id) on delete cascade,
  ap numeric default 0,
  apps integer default 0,
  doors_knocked integer default 0,
  dials integer default 0,
  contacts integer default 0,
  appts integer default 0,
  presentations integer default 0,
  sales integer default 0,
  recruiting integer default 0,
  ride_along text default '',
  hours_worked integer default 0,
  minutes_worked integer default 0,
  entry_date date not null default current_date,
  created_at timestamp with time zone default now()
);

-- SALE DETAILS TABLE (one row per individual sale)
create table if not exists sale_details (
  id uuid default gen_random_uuid() primary key,
  entry_id uuid references entries(id) on delete cascade,
  agent_id uuid references agents(id) on delete cascade,
  sale_type text default '',
  carrier text default '',
  lead_type text default '',
  face_amount numeric default 0,
  annual_premium numeric default 0,
  lead_age text default '',
  field_tele text default '',
  draft_date date,
  created_at timestamp with time zone default now()
);

-- Enable Row Level Security but allow all for anon (public app)
alter table agents enable row level security;
alter table entries enable row level security;
alter table sale_details enable row level security;

-- Allow public read/write (since this is a team internal tool)
create policy "Allow all on agents" on agents for all using (true) with check (true);
create policy "Allow all on entries" on entries for all using (true) with check (true);
create policy "Allow all on sale_details" on sale_details for all using (true) with check (true);
