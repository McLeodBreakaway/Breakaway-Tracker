# 🏆 Breakaway Tracker — Deployment Guide
### Get your team live in ~20 minutes. No coding required.

---

## WHAT YOU'LL CREATE
- A real web app at a link like: `breakaway-tracker.vercel.app`
- A database that stores all agent stats centrally
- Every agent visits the same link from their phone and data syncs instantly

---

## STEP 1 — Create Your Supabase Database (5 min)

**Supabase = your free database that stores all the data**

1. Go to **https://supabase.com**
2. Click **"Start your project"** → Sign up with Google or email
3. Click **"New Project"**
   - Name it: `breakaway-tracker`
   - Set a database password (save this somewhere)
   - Choose a region closest to you (e.g. US East)
   - Click **"Create new project"** — wait ~1 minute
4. Once loaded, click **"SQL Editor"** in the left sidebar
5. Click **"New query"**
6. Open the file `supabase-setup.sql` from this folder
7. Copy ALL the text from that file and paste it into the SQL editor
8. Click **"Run"** (green button)
9. You should see "Success" — your database tables are created!

**Now get your keys:**
10. Click **"Project Settings"** (gear icon, bottom left)
11. Click **"API"**
12. Copy and save these two values:
    - **Project URL** (looks like: `https://abcdefgh.supabase.co`)
    - **anon public** key (long string starting with `eyJ...`)

---

## STEP 2 — Upload Code to GitHub (5 min)

**GitHub = where your code lives (free)**

1. Go to **https://github.com** → Sign up or log in
2. Click the **"+"** icon top right → **"New repository"**
   - Name: `breakaway-tracker`
   - Set to **Private**
   - Click **"Create repository"**
3. On the next page, click **"uploading an existing file"**
4. Drag and drop the ENTIRE `breakaway-tracker` folder contents into the upload area
   - Make sure you see these files listed: `package.json`, `next.config.js`, and folders `src/`, etc.
5. Scroll down, click **"Commit changes"**

---

## STEP 3 — Deploy on Vercel (5 min)

**Vercel = hosts your app and gives you the link (free)**

1. Go to **https://vercel.com** → Sign up with your GitHub account
2. Click **"Add New Project"**
3. Find and click your `breakaway-tracker` repository → Click **"Import"**
4. On the configuration screen, leave everything default
5. **IMPORTANT** — Before clicking Deploy, scroll down to **"Environment Variables"**
6. Add these two variables (click "Add" for each):

   | Name | Value |
   |------|-------|
   | `NEXT_PUBLIC_SUPABASE_URL` | Your Project URL from Step 1 |
   | `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Your anon public key from Step 1 |

7. Click **"Deploy"**
8. Wait ~2 minutes for it to build
9. 🎉 You'll see a success screen with your live URL!

---

## STEP 4 — Add Your Agents

1. Open your new link (e.g. `breakaway-tracker.vercel.app`)
2. Tap **⚙️ Admin**
3. Enter PIN: **1234**
4. Add each agent's name one by one

---

## STEP 5 — Share With Your Team

Just send everyone the link! That's it.

```
Hey team! Use this link to log your daily stats:
https://your-app-name.vercel.app

Tap ➕ Log, pick your name, enter your numbers, hit Submit.
The leaderboard updates instantly for everyone.
```

---

## CHANGING THE ADMIN PIN

The default PIN is `1234`. To change it:
1. Go to your Vercel project dashboard
2. Click **Settings** → **Environment Variables**
3. Add: `ADMIN_PIN` = your new PIN
4. Click **Redeploy**

Or for now, just remember it's `1234` — only you know the link is your admin area.

---

## VIEWING YOUR DATA

You can see all raw data anytime:
1. Log into **supabase.com**
2. Open your project
3. Click **"Table Editor"**
4. Browse `agents`, `entries`, and `sale_details` tables like a spreadsheet

You can also export to CSV from there anytime!

---

## TROUBLESHOOTING

**"Missing Supabase environment variables" error**
→ Double-check you added both env variables in Vercel exactly as shown

**Agents not saving**
→ Make sure you ran the SQL script in Step 1 completely

**App not loading**
→ Check Vercel dashboard for build errors; make sure all files uploaded in Step 2

---

## NEED HELP?

If you get stuck on any step, take a screenshot of where you are and ask Claude — 
paste the error message and which step you're on.
