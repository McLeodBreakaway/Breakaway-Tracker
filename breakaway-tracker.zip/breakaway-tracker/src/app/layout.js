export const metadata = {
  title: 'Breakaway Tracker',
  description: 'Final Expense Team Production Tracker',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, padding: 0, background: '#0a0e1a' }}>
        {children}
      </body>
    </html>
  )
}
